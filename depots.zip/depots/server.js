const express = require('express');
const app = express();
const PORT = 3000;

// Route to get depots JSON
app.get('/depots', (req, res) => {
    const data = {
        depots: [
            {
                ID: 1,
                MechanicHours: 60
            },
            {
                ID: 2,
                MechanicHours: 135
            },
            {
                ID: 3,
                MechanicHours: 188
            },
            {
                ID: 4,
                MechanicHours: 97
            },
            {
                ID: 5,
                MechanicHours: 164
            }
        ]
    };
    res.json(data);
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
    console.log(`Access the depots JSON at http://localhost:${PORT}/depots`);
});

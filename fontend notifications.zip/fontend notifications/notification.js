module.exports = {
    "notification": [
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "Result",
            "Message": "mid-sem",
            "Timestamp": "2026-04-22 17:51:30"
        },
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "placement",
            "Message": "CSX Corporation hiring",
            "Timestamp": "2026-04-22 17:51:30"
        },
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "Event",
            "Message": "farewell",
            "Timestamp": "2026-04-22 17:51:30"
        },
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "Result",
            "Message": "project review",
            "Timestamp": "2026-04-22 17:51:30"
        },
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "Result",
            "Message": "external exam",
            "Timestamp": "2026-04-22 17:51:06"
        },
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "Result",
            "Message": "project review",
            "Timestamp": "2026-04-22 17:51:54"
        },
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "Result",
            "Message": "final-exam",
            "Timestamp": "2026-04-22 17:51:42"
        },
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "Event",
            "Message": "tech-fest",
            "Timestamp": "2026-04-22 17:51:18"
        },
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "Result",
            "Message": "project review",
            "Timestamp": "2026-04-22 17:51:06"
        },
        {
            "ID": "d14605a-0d86-4a34-9e69-3900a14576bdc",
            "Type": "placement",
            "Message": "micro company",
            "Timestamp": "2026-04-22 17:51:54"
        }
    ]
}
const express = require('express');
const app = express();
const PORT = process.env.PORT || 5000;

// Import notification data
const notificationData = require('./notification.js');

// Middleware
app.use(express.json());

// Routes
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to Notifications API', endpoints: ['/api/notifications', '/api/notifications/:id'] });
});

app.get('/api/notifications', (req, res) => {
  res.json(notificationData);
});

app.get('/api/notifications/:id', (req, res) => {
  const { id } = req.params;
  const notification = notificationData.notification.find(n => n.ID === id);
  
  if (notification) {
    res.json(notification);
  } else {
    res.status(404).json({ error: 'Notification not found' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
